let appHeader = `
    <nav style="background-color:MidnightBlue">
      <a href=index.html><button>Home</button></a>
      <a  href="test.html"><button>About</button></a>
      <a  href="blogposts/post1.html"><button>Blog</button></a>
    </nav>
`;
document.getElementById("app-header").innerHTML = appHeader;